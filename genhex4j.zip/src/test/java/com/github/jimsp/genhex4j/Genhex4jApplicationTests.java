package com.github.jimsp.genhex4j;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Genhex4jApplicationTests {

	@Test
	void contextLoads() {
	}

}
