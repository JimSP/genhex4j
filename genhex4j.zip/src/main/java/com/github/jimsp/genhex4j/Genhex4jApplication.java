package com.github.jimsp.genhex4j;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Genhex4jApplication {

	public static void main(String[] args) {
		SpringApplication.run(Genhex4jApplication.class, args);
	}

}
