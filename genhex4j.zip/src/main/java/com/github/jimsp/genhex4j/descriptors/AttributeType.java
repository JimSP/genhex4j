package com.github.jimsp.genhex4j.descriptors;

public enum AttributeType {
	DOMAIN, DTO, JPA
}
