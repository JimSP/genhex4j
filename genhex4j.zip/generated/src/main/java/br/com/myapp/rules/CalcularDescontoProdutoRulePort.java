package br.com.myapp.rules;

@FunctionalInterface
public interface CalcularDescontoProdutoRulePort extends java.util.function.Function<br.com.myapp.domains.ProdutoDomain, java.lang.Double>{

}
