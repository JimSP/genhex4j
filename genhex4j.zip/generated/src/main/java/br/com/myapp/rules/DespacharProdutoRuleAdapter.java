package br.com.myapp.rules;

import org.springframework.stereotype.Component;

@Component
public class DespacharProdutoRuleAdapter implements DespacharProdutoRulePort {

    @Override
    public void accept(final br.com.myapp.domains.ProdutoDomain input) {
        
final var domain = (Domain) input;
System.out.println(domain);

    }
}
