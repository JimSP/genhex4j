package br.com.myapp.rules;

import org.springframework.stereotype.Component;

@Component
public class CalcularDescontoProdutoRuleAdapter implements CalcularDescontoProdutoRulePort {

    @Override
    public java.lang.Double apply(final br.com.myapp.domains.ProdutoDomain input) {
        
public double applyDiscount(double price) {
    if (price > 100) {
        return price * 0.9;
    }
    return price;
}

    }
}
