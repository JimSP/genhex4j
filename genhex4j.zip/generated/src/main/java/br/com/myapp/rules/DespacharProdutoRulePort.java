package br.com.myapp.rules;

@FunctionalInterface
public interface DespacharProdutoRulePort extends java.util.function.Consumer<br.com.myapp.domains.ProdutoDomain>{

}
