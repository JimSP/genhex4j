# genhex4j
Gerador de Arquitetura Hexagonal à partir de desctitores JSON e templates freeMarker
